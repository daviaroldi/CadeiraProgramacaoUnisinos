package model;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.SecureRandom;
import java.security.spec.KeySpec;

public class Usuario {
    private String id;
    private String nome;
    private String cpf;
    private boolean administrador;
    private String username;
    private String password;

    public Usuario(String nome, String cpf, boolean administrador, String username, String password) {
        this.nome = nome;
        this.cpf = cpf;
        this.administrador = administrador;
        this.username = username;
        this.setPassword(password);
        
        this.id = java.util.UUID.randomUUID().toString();
    }

    public String getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public boolean isAdministrador() {
        return administrador;
    }

    public void setAdministrador(boolean administrador) {
        this.administrador = administrador;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    //TODO analisar se faz sentido existir esse metodo como publico
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        try {
            SecureRandom secureRandom = new SecureRandom();
            byte[] salt = new byte[16];
            secureRandom.nextBytes(salt);

            KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 65536, 128);
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            byte[] hash = factory.generateSecret(spec).getEncoded();

            this.password = hash.toString();
            System.out.println(this.password);
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
