package model;

public class SalvaAnalista {
	
	public void salvaAnalista (Analista analista) {
		//TODO salvar analista no BD
	}

}
